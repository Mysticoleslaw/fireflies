# GlowBug usermod for WLED

Servo arm hops 180° at random intervals; LED flashes on and fades out each hop.

## Wiring (D1 mini / D1 mini Pro)
- D1 (GPIO5) -> servo signal
- D4 (GPIO2) -> 330 Ω -> WS2812B DIN
- 5V -> servo + LED (via 1N4148/1N4001 diode to LED +) ; GND common
- 470 µF across 5V/GND

## Build
1. `git clone https://github.com/wled/WLED.git`
2. Copy this folder to `WLED/usermods/glowbug/`
3. Copy `platformio_override.ini` to the WLED root
4. VS Code + PlatformIO: build & upload env `glowbug` (or `pio run -e glowbug -t upload`)
5. Later updates: WLED UI -> Config -> Security & Updates -> Manual OTA (upload `.pio/build/glowbug/firmware.bin`)

## Settings (Config -> Usermods -> GlowBug)
| Setting | Default | Notes |
|---|---|---|
| pin | 5 | servo pin (D1) |
| minWait / maxWait | 10 / 30 | seconds between hops |
| pulseA / pulseB | 500 / 2500 | µs; tune for exact 180° without buzzing |
| swingMs | 500 | servo drive time per hop |
| fadeMs | 1200 | LED fade after landing |
| randomColour | on | off = use WLED's colour / palette / effect |
| alwaysLit | off | on = LED behaves like normal WLED |
| syncMode | Independent | Leader broadcasts hops; Followers copy them |
| staggerMs | 0 | followers: random delay so hops ripple |

## Control
- WLED on/off = bugs active/resting (works from WLED app, Home Assistant, timers)
- Night only: Config -> Time & Macros -> sunset "on" / sunrise "off" presets
- Sync colours: Config -> Sync Interfaces -> UDP send/receive on all bugs
- API: `{"GlowBug":{"hop":true}}` hop now, `{"GlowBug":{"on":false}}` pause
