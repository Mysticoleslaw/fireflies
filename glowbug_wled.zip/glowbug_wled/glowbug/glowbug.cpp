#include "wled.h"
#include <Servo.h>

/*
 * GlowBug usermod
 * --------------------------------------------------------------
 * A micro servo swings an arm 180° at random intervals. On each hop
 * the LED(s) flash on and then fade out, like a firefly landing.
 *
 * - Hops only while WLED is ON (turn off in the app = bugs rest).
 * - Colour: random per hop, or whatever WLED is showing
 *   (solid colour, palette, effect) when "randomColour" is off.
 * - Sync: one bug set to "leader" broadcasts each hop over UDP;
 *   "followers" hop with it (optionally staggered).
 * - API: {"GlowBug":{"hop":true}} triggers a hop now,
 *        {"GlowBug":{"on":false}} pauses hopping.
 *
 * All settings: WLED -> Config -> Usermods -> GlowBug
 */

#define GB_SYNC_PORT 21330

class GlowBug : public Usermod {
  private:
    // ---- settings ----
    bool     enabled      = true;
    int8_t   servoPin     = 5;      // D1 on D1 mini
    uint16_t minWait      = 10;     // s
    uint16_t maxWait      = 30;     // s
    uint16_t pulseA       = 500;    // µs, one end of travel
    uint16_t pulseB       = 2500;   // µs, other end
    uint16_t swingMs      = 500;    // how long the servo is driven per hop
    uint16_t fadeMs       = 1200;   // LED fade-out after landing
    bool     randomColour = true;   // false = use WLED's own colour/effect
    bool     alwaysLit    = false;  // true = LED stays on (WLED normal), only servo hops
    uint8_t  syncMode     = 0;      // 0 = independent, 1 = leader, 2 = follower
    uint16_t staggerMs    = 0;      // followers: random delay 0..stagger before hopping

    // ---- runtime ----
    Servo    servo;
    WiFiUDP  udp;
    bool     udpReady     = false;
    bool     initDone     = false;
    bool     atB          = false;
    bool     servoActive  = false;
    bool     hopPending   = false;
    uint32_t hopAt        = 0;      // when a pending (follower/API) hop fires
    uint32_t lastHop      = 0;
    uint32_t nextHop      = 0;
    uint32_t hopColour    = 0;
    uint8_t  envelope     = 0;      // LED brightness envelope 0..255

    static const char _name[];

    static uint32_t hueToRgb(uint16_t hue) { // hue 0..1535, full saturation
      uint8_t pos = hue & 0xFF;
      switch (hue >> 8) {
        case 0:  return RGBW32(255, pos, 0, 0);
        case 1:  return RGBW32(255 - pos, 255, 0, 0);
        case 2:  return RGBW32(0, 255, pos, 0);
        case 3:  return RGBW32(0, 255 - pos, 255, 0);
        case 4:  return RGBW32(pos, 0, 255, 0);
        default: return RGBW32(255, 0, 255 - pos, 0);
      }
    }

    void scheduleNext() {
      uint16_t lo = min(minWait, maxWait), hi = max(minWait, maxWait);
      nextHop = millis() + 1000UL * random(lo, hi + 1);
    }

    void broadcastHop() {
      if (!udpReady || !WLED_CONNECTED) return;
      IPAddress bc = (uint32_t)WiFi.localIP() | ~(uint32_t)WiFi.subnetMask();
      udp.beginPacket(bc, GB_SYNC_PORT);
      udp.write((const uint8_t*)"GBHOP", 5);
      udp.endPacket();
    }

    void hop() {
      if (servoPin >= 0) {
        atB = !atB;
        if (!servo.attached()) servo.attach(servoPin, min(pulseA, pulseB), max(pulseA, pulseB));
        servo.writeMicroseconds(atB ? pulseB : pulseA);
        servoActive = true;
      }
      hopColour = hueToRgb(random(1536));
      lastHop   = millis();
      envelope  = 255;
      strip.trigger();
      if (syncMode == 1) broadcastHop();
      scheduleNext();
    }

    bool active() { return enabled && bri > 0 && !offMode; }

  public:
    void setup() override {
      if (servoPin >= 0 && !PinManager::allocatePin(servoPin, true, PinOwner::UM_Unspecified)) {
        servoPin = -1; // pin taken by something else
      }
      if (servoPin >= 0) {
        pinMode(servoPin, OUTPUT);
        digitalWrite(servoPin, LOW);
      }
      randomSeed(RANDOM_REG32);    // ESP8266 hardware RNG
      scheduleNext();
      initDone = true;
    }

    void connected() override {
      udp.stop();
      udpReady = udp.begin(GB_SYNC_PORT);
    }

    void loop() override {
      if (!initDone) return;
      uint32_t now = millis();

      // stop driving the servo after the swing -> goes limp, saves power
      if (servoActive && now - lastHop > swingMs) {
        servo.detach();
        digitalWrite(servoPin, LOW);
        servoActive = false;
      }

      // listen for leader hops
      if (udpReady) {
        int len = udp.parsePacket();
        if (len > 0) {
          char buf[8] = {0};
          udp.read(buf, min(len, 7));
          if (syncMode == 2 && strncmp(buf, "GBHOP", 5) == 0 && active() && !hopPending) {
            hopPending = true;
            hopAt = now + (staggerMs ? random(staggerMs + 1) : 0);
          }
        }
      }

      if (active()) {
        if (hopPending && (int32_t)(now - hopAt) >= 0) { hopPending = false; hop(); }
        else if (syncMode != 2 && (int32_t)(now - nextHop) >= 0) hop();
      } else {
        hopPending = false;
        if ((int32_t)(now - nextHop) >= 0) scheduleNext(); // don't burst-hop when switched back on
      }

      // LED envelope: full on while swinging, then linear fade
      if (envelope > 0) {
        uint32_t t = now - lastHop;
        uint8_t e = 0;
        if (t < swingMs) e = 255;
        else if (t < (uint32_t)swingMs + fadeMs) e = 255 - (255UL * (t - swingMs)) / max((uint16_t)1, fadeMs);
        envelope = e;
        strip.trigger(); // keep frames coming while fading (also draws the final black frame)
      }
    }

    void handleOverlayDraw() override {
      if (alwaysLit) return;  // paused bugs stay dark; alwaysLit hands the LED back to WLED
      uint16_t n = strip.getLengthTotal();
      for (uint16_t i = 0; i < n; i++) {
        uint32_t c = randomColour ? hopColour : strip.getPixelColor(i);
        strip.setPixelColor(i, envelope ? color_fade(c, envelope) : 0);
      }
    }

    void addToJsonInfo(JsonObject& root) override {
      JsonObject user = root["u"];
      if (user.isNull()) user = root.createNestedObject("u");
      JsonArray arr = user.createNestedArray(FPSTR(_name));
      if (!enabled)            arr.add(F("paused"));
      else if (syncMode == 2)  arr.add(F("follower"));
      else {
        long s = ((int32_t)(nextHop - millis())) / 1000;
        arr.add(String(F("next hop in ")) + String(max(0L, s)) + F("s"));
      }
    }

    void addToJsonState(JsonObject& root) override {
      if (!initDone) return;
      JsonObject um = root[FPSTR(_name)];
      if (um.isNull()) um = root.createNestedObject(FPSTR(_name));
      um["on"] = enabled;
    }

    void readFromJsonState(JsonObject& root) override {
      if (!initDone) return;
      JsonObject um = root[FPSTR(_name)];
      if (um.isNull()) return;
      if (um["on"].is<bool>()) enabled = um["on"].as<bool>();
      if (um["hop"] | false) { hopPending = true; hopAt = millis(); }
    }

    void addToConfig(JsonObject& root) override {
      JsonObject top = root.createNestedObject(FPSTR(_name));
      top["enabled"]      = enabled;
      top["pin"]          = servoPin;
      top["minWait"]      = minWait;
      top["maxWait"]      = maxWait;
      top["pulseA"]       = pulseA;
      top["pulseB"]       = pulseB;
      top["swingMs"]      = swingMs;
      top["fadeMs"]       = fadeMs;
      top["randomColour"] = randomColour;
      top["alwaysLit"]    = alwaysLit;
      top["syncMode"]     = syncMode;
      top["staggerMs"]    = staggerMs;
    }

    bool readFromConfig(JsonObject& root) override {
      JsonObject top = root[FPSTR(_name)];
      int8_t oldPin = servoPin;
      bool ok = !top.isNull();
      ok &= getJsonValue(top["enabled"],      enabled,      true);
      ok &= getJsonValue(top["pin"],          servoPin,     (int8_t)5);
      ok &= getJsonValue(top["minWait"],      minWait,      (uint16_t)10);
      ok &= getJsonValue(top["maxWait"],      maxWait,      (uint16_t)30);
      ok &= getJsonValue(top["pulseA"],       pulseA,       (uint16_t)500);
      ok &= getJsonValue(top["pulseB"],       pulseB,       (uint16_t)2500);
      ok &= getJsonValue(top["swingMs"],      swingMs,      (uint16_t)500);
      ok &= getJsonValue(top["fadeMs"],       fadeMs,       (uint16_t)1200);
      ok &= getJsonValue(top["randomColour"], randomColour, true);
      ok &= getJsonValue(top["alwaysLit"],    alwaysLit,    false);
      ok &= getJsonValue(top["syncMode"],     syncMode,     (uint8_t)0);
      ok &= getJsonValue(top["staggerMs"],    staggerMs,    (uint16_t)0);

      if (initDone && oldPin != servoPin) { // pin changed from settings page
        if (servo.attached()) servo.detach();
        if (oldPin >= 0) PinManager::deallocatePin(oldPin, PinOwner::UM_Unspecified);
        setup();
      }
      return ok;
    }

    void appendConfigData() override {
      oappend(F("addInfo('GlowBug:pin',1,'servo signal (D1 = GPIO5)');"));
      oappend(F("addInfo('GlowBug:minWait',1,'s');"));
      oappend(F("addInfo('GlowBug:maxWait',1,'s');"));
      oappend(F("addInfo('GlowBug:pulseA',1,'&micro;s, tune for exact 180&deg;');"));
      oappend(F("addInfo('GlowBug:pulseB',1,'&micro;s');"));
      oappend(F("addInfo('GlowBug:randomColour',1,'off = use the colour/effect set in WLED');"));
      oappend(F("addInfo('GlowBug:alwaysLit',1,'LED stays on instead of flash + fade');"));
      oappend(F("dd=addDropdown('GlowBug','syncMode');"));
      oappend(F("addOption(dd,'Independent',0);"));
      oappend(F("addOption(dd,'Leader',1);"));
      oappend(F("addOption(dd,'Follower',2);"));
      oappend(F("addInfo('GlowBug:staggerMs',1,'followers: random delay so they ripple');"));
    }
};

const char GlowBug::_name[] PROGMEM = "GlowBug";

static GlowBug glowbug;
REGISTER_USERMOD(glowbug);
